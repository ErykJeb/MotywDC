[download-image]: https://i.imgur.com/aFT3bFw.png

[T1-download-link]: https://betterdiscord.app/Download?id=218

# Themes for BetterDiscord

CSS code that changes the default appearance of Discord.


## Themes:

- [T1 - Theme](https://betterdiscord.app/theme/T1) | [download][T1-download-link] [![download-image]][T1-download-link]



## Install:

1. head into your "Themes" Settings.
2. open Themes Folder.
3. drop in the theme.css file.
4. enable the Theme and enjoy.


## Customize:

Edit the theme.css file in a Texteditor
