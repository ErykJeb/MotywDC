# BetterDiscord Stuff by Eight_P

#### [BetterDiscord](https://betterdiscord.app/) allows the installation of user-created [Themes](Themes) and Plugins injected into Discord.
